# GEYGO_PROJECT

Android application project built with Kotlin, Jetpack Compose, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Gradle 8.9, and JDK 17.

## Open in Android Studio

1. Extract this ZIP to a normal writable folder.
2. Open the `GEYGO_PROJECT_AndroidStudio_FIXED` folder in Android Studio.
3. Install Android SDK Platform 35 and Android SDK Build-Tools 35.x when prompted.
4. Set Gradle JDK to JDK 17 (Android Studio: Settings > Build, Execution, Deployment > Build Tools > Gradle).
5. Sync the project, then choose Build > Generate App Bundles or APKs > Build APK(s).

The project includes lightweight `gradlew` launch scripts that download the pinned Gradle 8.9 distribution on Linux/macOS or Windows. They are bootstrap scripts; the standard Gradle Wrapper JAR is not included in this archive. If Android Studio insists on a missing `gradle-wrapper.jar`, use the GitHub Actions workflow below or generate the standard wrapper from an installed Gradle 8.9 installation with `gradle wrapper --gradle-version 8.9`.

## Build APK using GitHub Actions

1. Upload/extract this project into a GitHub repository on branch `main` or `master`.
2. Open the repository's Actions tab.
3. Run **Build GEYGO Release APK** (or push a commit to `main`/`master`).
4. Download the `GEYGO-release-apk` artifact from the completed workflow.

The workflow installs Gradle 8.9 and JDK 17 directly, so it does not depend on a checked-in Gradle Wrapper JAR.

## Build locally from terminal

- Linux/macOS: `./gradlew :app:assembleRelease`
- Windows: `gradlew.bat :app:assembleRelease`

A compatible Android SDK (Platform 35) and JDK 17 are required. The first build needs internet access to download Gradle and Android/Google Maven dependencies.

## Prototype limitations

- Login, chat, shop, wallet, and premium activation are demo/local UI only.
- Premium code `GEYGOZUR.M` is checked locally and is not secure production authentication.
- No real payment, account backend, or server-side chat is connected.
