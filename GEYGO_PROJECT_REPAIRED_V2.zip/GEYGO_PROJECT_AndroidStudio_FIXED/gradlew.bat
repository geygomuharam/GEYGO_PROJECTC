@echo off
setlocal
set APP_HOME=%~dp0
set DIST_URL=
for /f "tokens=1,* delims==" %%A in ('findstr /b "distributionUrl=" "%APP_HOME%gradle\wrapper\gradle-wrapper.properties"') do set DIST_URL=%%B
set DIST_URL=%DIST_URL:\:=:%
for %%I in ("%DIST_URL%") do set DIST_FILE=%%~nxI
set DIST_NAME=%DIST_FILE:.zip=%
if not defined GRADLE_USER_HOME set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set DIST_DIR=%GRADLE_USER_HOME%\wrapper\dists\%DIST_NAME%\manual-install
set GRADLE_BIN=%DIST_DIR%\%DIST_NAME%\bin\gradle.bat
if not exist "%GRADLE_BIN%" (
  if not exist "%DIST_DIR%" mkdir "%DIST_DIR%"
  echo Downloading %DIST_URL% ...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%DIST_URL%' -OutFile '%DIST_DIR%\%DIST_NAME%.zip'; Expand-Archive -Force '%DIST_DIR%\%DIST_NAME%.zip' '%DIST_DIR%'"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_BIN%" -p "%APP_HOME%" %*
exit /b %ERRORLEVEL%
