package com.geygo.project

import android.os.Bundle
import android.media.MediaPlayer
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.*
import androidx.compose.ui.draw.animateContentSize
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val BG=Color(0xFF0B0B12); private val PANEL=Color(0xFF171724)
private val PURPLE=Color(0xFF8B5CF6); private val MUTED=Color(0xFFAAA8BA)

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{GeygoApp()}}
}

@Composable fun GeygoApp(){
 var login by remember{mutableStateOf(false)}
 var tab by remember{mutableIntStateOf(0)}
 var premium by remember{mutableStateOf(false)}
 var musicOn by remember{mutableStateOf(false)}
 val context= LocalContext.current
 val player= remember { MediaPlayer.create(context,R.raw.geygo_music)?.apply { isLooping=true } }
 LaunchedEffect(musicOn,login){
  if(musicOn && login) { player?.let { if(!it.isPlaying) it.start() } }
  else player?.pause()
 }
 DisposableEffect(Unit){ onDispose { player?.release() } }
 MaterialTheme(colorScheme=darkColorScheme(primary=PURPLE,background=BG,surface=PANEL)){
  Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF071A32),BG,Color(0xFF101027))))) {
   AnimatedBlueBackdrop()
   Surface(Modifier.fillMaxSize(),color=Color.Transparent){
    when{
     !login->LoginScreen{login=true}
     premium->PremiumScreen{premium=false}
     else->Scaffold(containerColor=Color.Transparent,
      floatingActionButton={
       FloatingActionButton(onClick={musicOn=!musicOn},containerColor=if(musicOn) PURPLE else PANEL,contentColor=Color.White){
        Icon(if(musicOn) Icons.Default.MusicOff else Icons.Default.MusicNote,contentDescription=if(musicOn) "Matikan musik" else "Putar musik")
       }
      },bottomBar={
       NavigationBar(containerColor=PANEL.copy(alpha=.96f)){
        val names=listOf("Home","Shop","Chat","Wallet","Profile")
        val icons=listOf(Icons.Default.Home,Icons.Default.Store,Icons.Default.Chat,Icons.Default.AccountBalanceWallet,Icons.Default.Person)
        names.forEachIndexed{i,n->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(icons[i],n)},label={Text(n)})}
       }
      }){pad->
       Box(Modifier.padding(pad)){
        AnimatedContent(targetState=tab,transitionSpec={
         (fadeIn(tween(320))+slideInVertically(tween(320)){it/12}) togetherWith
          (fadeOut(tween(180))+slideOutVertically(tween(180)){-it/16})
        },label="tab-transition"){ page->
         when(page){0->HomeScreen{premium=true};1->ShopScreen();2->ChatScreen();3->WalletScreen();else->ProfileScreen({premium=true}){login=false;tab=0;musicOn=false}}
        }
       }
      }
    }
   }
  }
 }
}

@Composable fun AnimatedBlueBackdrop(){
 val infinite= rememberInfiniteTransition(label="blue-particles")
 val drift by infinite.animateFloat(0f,1f,infiniteRepeatable(tween(9000,easing=LinearEasing),RepeatMode.Reverse),label="drift")
 val pulse by infinite.animateFloat(.18f,.48f,infiniteRepeatable(tween(2400,easing=FastOutSlowInEasing),RepeatMode.Reverse),label="pulse")
 Canvas(Modifier.fillMaxSize()){
  val w=size.width; val h=size.height
  drawCircle(Color(0xFF168BFF).copy(alpha=pulse*.22f),radius=size.minDimension*.34f,center=androidx.compose.ui.geometry.Offset(w*(.15f+.12f*drift),h*.22f))
  drawCircle(Color(0xFF5B4BFF).copy(alpha=pulse*.18f),radius=size.minDimension*.30f,center=androidx.compose.ui.geometry.Offset(w*(.86f-.10f*drift),h*.72f))
  for(i in 0..22){
   val x=((i*73f)%w + drift*if(i%2==0) 36f else -28f).mod(w)
   val y=((i*137f)%h)
   val r=if(i%4==0) 3.2f else 1.5f
   drawCircle(Color(0xFF75DFFF).copy(alpha=.12f+pulse*.24f),r,androidx.compose.ui.geometry.Offset(x,y))
  }
 }
}

@Composable fun LoginScreen(onEnter:()->Unit){
 var email by remember{mutableStateOf("")};var pass by remember{mutableStateOf("")};var reg by remember{mutableStateOf(false)}
 Column(Modifier.fillMaxSize().background(BG).padding(24.dp),verticalArrangement=Arrangement.Center){
  Icon(Icons.Default.Bolt,null,tint=PURPLE,modifier=Modifier.size(56.dp))
  Text("GEYGO_PROJECT",fontSize=28.sp,fontWeight=FontWeight.Black,color=Color.White)
  Text("Your digital space, reimagined.",color=MUTED)
  Spacer(Modifier.height(28.dp));Text(if(reg)"Create account" else "Welcome back",fontSize=22.sp,fontWeight=FontWeight.Bold)
  OutlinedTextField(email,{email=it},label={Text("Email")},modifier=Modifier.fillMaxWidth())
  OutlinedTextField(pass,{pass=it},label={Text("Password")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
  Spacer(Modifier.height(14.dp))
  Button(onClick=onEnter,enabled=email.isNotBlank()&&pass.isNotBlank(),modifier=Modifier.fillMaxWidth()){Text(if(reg)"Register (demo)" else "Sign in (demo)")}
  TextButton(onClick={reg=!reg},modifier=Modifier.align(Alignment.CenterHorizontally)){Text(if(reg)"Back to sign in" else "Create account")}
  Text("Demo login only. Connect secure authentication before publishing.",color=MUTED,fontSize=11.sp)
 }
}
@Composable fun Header(title:String,sub:String){Column(Modifier.padding(20.dp)){Text(title,fontSize=27.sp,fontWeight=FontWeight.Black);Text(sub,color=MUTED)}}
@Composable fun Section(t:String){Text(t,Modifier.padding(start=20.dp,top=22.dp,bottom=10.dp),fontSize=18.sp,fontWeight=FontWeight.Bold)}
@Composable fun Tile(icon:androidx.compose.ui.graphics.vector.ImageVector,title:String,sub:String,onClick:(()->Unit)?=null){
 Card(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=5.dp).animateContentSize().then(if(onClick!=null)Modifier.clickable{onClick()}else Modifier),colors=CardDefaults.cardColors(containerColor=PANEL)){
  Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=PURPLE);Spacer(Modifier.width(12.dp));Column{Text(title,fontWeight=FontWeight.Bold);Text(sub,color=MUTED,fontSize=12.sp)}}
 }
}
@Composable fun HomeScreen(premium:()->Unit){
 LazyColumn{
  item{Header("GEYGO_PROJECT","Your digital space, reimagined.")}
  item{val glow by rememberInfiniteTransition(label="premium-glow").animateFloat(.88f,1f,infiniteRepeatable(tween(1500),RepeatMode.Reverse),label="glow")
  Column(Modifier.fillMaxWidth().graphicsLayer{scaleX=glow;scaleY=glow}.padding(horizontal=16.dp).background(Brush.linearGradient(listOf(Color(0xFF6D28D9),Color(0xFF312E81))),RoundedCornerShape(24.dp)).padding(22.dp)){
   Text("✦ GEYGO PREMIUM",fontWeight=FontWeight.Bold);Spacer(Modifier.height(14.dp))
   Text("Unlock your premium experience",fontSize=25.sp,fontWeight=FontWeight.Black)
   Text("More tools. More control. One place.")
   Button(onClick=premium){Text("Activate Premium")}
  }}
  item{Section("Quick access")}
  item{Tile(Icons.Default.Store,"Marketplace","Explore catalogue")}
  item{Tile(Icons.Default.Chat,"Messages","Your conversations")}
  item{Tile(Icons.Default.AccountBalanceWallet,"My wallet","Account overview")}
  item{Tile(Icons.Default.Security,"Security","Protect your account")}
 }
}
@Composable fun ShopScreen(){
 var q by remember{mutableStateOf("")};val products=listOf("Starter Pack — Rp 25.000","Creator Kit — Rp 49.000","Pro Template — Rp 75.000","Business Kit — Rp 99.000")
 Column{Header("Marketplace","Discover products and services.")
  OutlinedTextField(q,{q=it},modifier=Modifier.fillMaxWidth().padding(horizontal=16.dp),label={Text("Search products")})
  products.filter{it.contains(q,true)}.forEach{Tile(Icons.Default.Inventory2,it,"Demo catalogue · Checkout not connected")}
 }
}
@Composable fun ChatScreen(){
 var input by remember{mutableStateOf("")};val msgs= remember{mutableStateListOf<String>()}
 Column(Modifier.fillMaxSize()){
  Header("Messages","Local chat preview")
  Column(Modifier.weight(1f).fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.Bottom){
   if(msgs.isEmpty())Text("Belum ada pesan.",color=MUTED)
   msgs.forEach{Text(it,Modifier.align(Alignment.End).padding(5.dp).background(PURPLE.copy(alpha=.25f),RoundedCornerShape(12.dp)).padding(12.dp))}
  }
  Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){
   OutlinedTextField(input,{input=it},modifier=Modifier.weight(1f),label={Text("Tulis pesan")})
   IconButton(onClick={if(input.isNotBlank()){msgs.add(input.trim());input=""}}){Icon(Icons.Default.Send,null,tint=PURPLE)}
  }
  Text("Pesan hanya tersimpan sementara.",color=MUTED,fontSize=10.sp,modifier=Modifier.align(Alignment.CenterHorizontally))
 }
}
@Composable fun WalletScreen(){
 Column{Header("My Wallet","Account and transaction overview.")
  Card(Modifier.fillMaxWidth().padding(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFF30205B))){
   Column(Modifier.padding(22.dp)){Text("DEMO BALANCE",color=MUTED);Text("Rp 0",fontSize=32.sp,fontWeight=FontWeight.Black);Text("No real funds stored in this prototype.")}
  }
  Row(Modifier.padding(horizontal=16.dp)){Button(onClick={},modifier=Modifier.weight(1f)){Text("Top up")};Spacer(Modifier.width(8.dp));OutlinedButton(onClick={},modifier=Modifier.weight(1f)){Text("Withdraw")}}
  Section("Recent transactions");Tile(Icons.Default.ReceiptLong,"No transactions yet","Verified transactions appear here.")
 }
}
@Composable fun PremiumScreen(back:()->Unit){
 var code by remember{mutableStateOf("")};var active by remember{mutableStateOf(false)}
 val ctx=androidx.compose.ui.platform.LocalContext.current
 Column(Modifier.fillMaxSize().padding(20.dp)){
  Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick=back){Icon(Icons.Default.ArrowBack,null)};Text("GEYGO PREMIUM",fontSize=20.sp,fontWeight=FontWeight.Bold)}
  Spacer(Modifier.height(20.dp))
  Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF3A2470))){Column(Modifier.padding(22.dp)){Icon(Icons.Default.WorkspacePremium,null,modifier=Modifier.size(42.dp));Text("Premium access",fontSize=26.sp,fontWeight=FontWeight.Black);Text("Masukkan kode aktivasi GEYGO_PROJECT.")}}
  Spacer(Modifier.height(20.dp));OutlinedTextField(code,{code=it},modifier=Modifier.fillMaxWidth(),label={Text("Kode premium")})
  Button(onClick={active=code.trim()=="GEYGOZUR.M";Toast.makeText(ctx,if(active)"Premium demo aktif" else "Kode tidak valid",Toast.LENGTH_SHORT).show()},modifier=Modifier.fillMaxWidth()){Text("Aktifkan Premium")}
  if(active)Tile(Icons.Default.Verified,"Premium demo aktif","Aktivasi lokal berhasil.")
  Spacer(Modifier.height(12.dp));Text("Pemeriksaan kode ini hanya demo lokal. Premium produksi harus diverifikasi server.",color=MUTED,fontSize=12.sp)
 }
}
@Composable fun ProfileScreen(premium:()->Unit,logout:()->Unit){
 Column{Header("My Profile","Manage your GEYGO_PROJECT account.")
  Tile(Icons.Default.Person,"Guest member","Demo account")
  Tile(Icons.Default.WorkspacePremium,"Membership","Free plan · Premium demo available",premium)
  Tile(Icons.Default.Notifications,"Notifications","Notification preferences")
  Tile(Icons.Default.Lock,"Privacy & security","Account protection")
  Tile(Icons.Default.HelpOutline,"Help & support","Support and FAQ")
  OutlinedButton(onClick=logout,modifier=Modifier.fillMaxWidth().padding(16.dp)){Text("Sign out")}
 }
}
